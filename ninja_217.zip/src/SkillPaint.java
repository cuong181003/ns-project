public final class SkillPaint {
   public int id;
   public SkillInfoPaint[] skillStand;
   public SkillInfoPaint[] skillfly;
}
