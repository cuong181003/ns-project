public final class EffectCharPaint {
   public int idEf;
   public EffectInfoPaint[] arrEfInfo;
}
