final class EffectPosition extends BaseEPosition {
   EffectPosition(AnimateEffect var1, Position var2, int var3, int var4) {
   }
}
