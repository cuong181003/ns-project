public final class Set {
   public int time;
   public int xMob;
   public int yMob;
   public int xChar;
   public int yChar;
}
