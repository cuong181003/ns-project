
public class upgrade_2 {

    public static upgrade_2 advAB= new upgrade_2();
    public int advAG = 0;
    public int advAH = 13;
    public int advAI = 6;
    public int advAJ = 4;
    public int advAK = 11;
    public int advAL = 2;
    public int advAM = 7;
    public int advAN = 8;
    public int advAO = 15;

    public static upgrade_2 gI() {
        return advAB;
    }

}
