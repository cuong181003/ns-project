public final class ImageInfo {
   public int x0;
   public int y0;
   public int w;
   public int h;
}
