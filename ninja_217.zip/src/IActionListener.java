public interface IActionListener {
   void perform(int var1, Object var2);
}
