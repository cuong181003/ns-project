public final class NClass {
   public int classId;
   public String name;
   public SkillTemplate[] skillTemplates;
}
