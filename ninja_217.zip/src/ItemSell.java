public final class ItemSell {
   public final ItemTemplate template;
   public final int id;
   public final String name;

   public ItemSell(ItemTemplate var1, int var2, String var3) {
      this.template = var1;
      this.id = var2;
      this.name = var3;
   }
}
