public final class MovePoint {
   public int xEnd;
   public int yEnd;
   public int status;

   public MovePoint(int var1, int var2, int var3, int var4) {
      this.xEnd = var1;
      this.yEnd = var2;
      this.status = var3;
   }

   public MovePoint(int var1, int var2) {
      this.xEnd = var1;
      this.yEnd = var2;
   }
}
