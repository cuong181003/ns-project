final class AutoNTGT2 {
   final long ntgtAA;
   private final byte ntgtAC;
   private final String ntgtAD;
   private final boolean ntgtAE;
   public byte ntgtAB;

   public AutoNTGT2(long var1, byte var3, String var4, boolean var5) {
      this.ntgtAD = var4;
      this.ntgtAA = var1;
      this.ntgtAC = var3;
      this.ntgtAE = var5;
      this.ntgtAB = -1;
   }

   public final byte ntgtAA() {
      return this.ntgtAC;
   }

   public final boolean ntgtAB() {
      return this.ntgtAE;
   }

   public final String ntgtAC() {
      return this.ntgtAD;
   }
}
