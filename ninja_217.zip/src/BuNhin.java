public final class BuNhin {
   public short x;
   public short y;
   public String name;
   public boolean isInjure = false;

   public BuNhin(String var1, short var2, short var3) {
      this.x = var2;
      this.y = var3;
      this.name = var1;
   }
}
