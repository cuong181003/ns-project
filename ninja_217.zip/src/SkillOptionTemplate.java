public final class SkillOptionTemplate {
   public int id;
   public String name;
}
