public final class EffectTemplate {
   public byte id;
   public byte type;
   public int iconId;	public String name;

}
