public final class SkillTemplate {
   public byte id;
   public String name;
   public int maxPoint;
   public int type;
   public int iconId;
   public String[] description;
   public Skill[] skills;
}
