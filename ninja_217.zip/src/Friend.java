public final class Friend {
   public String friendName;
   public byte type;

   public Friend(String var1, byte var2) {
      this.friendName = var1;
      this.type = var2;
   }
}
