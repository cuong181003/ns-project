public final class FrameEff {
   public MyVector listPartTop = new MyVector();
   public MyVector listPartBottom = new MyVector();

   public FrameEff(MyVector var1, MyVector var2) {
      this.listPartTop = var1;
      this.listPartBottom = var2;
   }
}
