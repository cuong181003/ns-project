public final class DunItem {
   public int id;
   public String name1;
   public String name2;
}
