import javax.microedition.lcdui.Image;

public final class ImageIcon {
   public Image img;
   public long timeGetBack;
}
