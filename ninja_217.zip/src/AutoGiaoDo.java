public final class AutoGiaoDo extends Auto {
   private static AutoGiaoDo sellerBG;
   public long sellerAA;
   private long sellerBH;
   private int sellerBI;
   public int sellerAY;
   public int sellerAZ;
   public static MyVector sellerBA = new MyVector();
   public Char sellerBB;
   private String[] sellerBJ;
   private String sellerBK;
   private int sellerBL = 0;
   public long sellerBC = 0L;
   public long sellerBD = 0L;
   public int sellerBE = 0;
   public int sellerBF = -1;

   public static AutoGiaoDo sellerAN() {
      if (sellerBG == null) {
         sellerBG = new AutoGiaoDo();
      }

      return sellerBG;
   }

   private void sellerAQ() {
      this.sellerBB = null;
      this.sellerAY = 0;
      this.sellerBH = 0L;
      this.sellerBI = 0;
      this.sellerAZ = -1;
      this.sellerBL = 0;
      this.sellerAA = 0L;
   }

   public static void sellerAO() {
      String var0 = "";
      if (!sellerBA.isEmpty()) {
         for(int var1 = 0; var1 < sellerBA.size(); ++var1) {
            String var2;
            if ((var2 = (String)sellerBA.elementAt(var1)) != null && var2.length() > 0) {
               if (var0.length() > 0) {
                  var0 = var0 + ";";
               }

               var0 = var0 + var2;
            }
         }
      }

      if (var0.length() > 0) {
         RMS.saveRMSString("chipSellerLists", var0);
      } else {
         RMS.deleteRecord("chipSellerLists");
      }
   }

   public static MyVector sellerAP() {
      MyVector var0 = new MyVector();
      if (!sellerBA.isEmpty()) {
         for(int var1 = 0; var1 < sellerBA.size(); ++var1) {
            String var2 = (String)sellerBA.elementAt(var1);
            var0.addElement(var1 + 1 + ". " + var2);
         }
      }

      return var0;
   }

   public final boolean sellerAA(String var1, String var2) {
      if (!sellerAC(var1)) {
         return false;
      } else {
         if (var2.startsWith("@cmdcall")) {
            String[] var9;
            if ((var2 = Code.sellerAI(var2)) != null && var2.length() > 0 && (var9 = Code.advAC(var2, " ")).length >= 2) {
               String[] var3;
               if (sellerAA(var3 = Code.advAC(var9[1], ":"))) {
                  var9 = Code.advAC(var9[0], ":");

                  try {
                     int var4 = Integer.parseInt(var9[0]);
                     int var5 = Integer.parseInt(var9[1]);
                     int var10 = Integer.parseInt(var9[2]);
                     AutoGiaoDo var10000 = sellerAN();
                     int var10002 = var4;
                     int var10003 = var5;
                     String[] var6 = var3;
                     var5 = var10;
                     var4 = var10003;
                     int var11 = var10002;
                     var2 = var1;
                     AutoGiaoDo var8 = var10000;
                     var10000.advAI();
                     var8.sellerAQ();
                     var8.sellerBK = var2;
                     var8.mapID = var11;
                     var8.zoneID = var4;
                     var8.advAG = TileMap.isHang(var11);
                     var8.sellerAZ = var5;
                     var8.sellerBJ = var6;
                     Code.advAA((Auto)sellerAN());
                     return true;
                  } catch (Exception var7) {
                     return false;
                  }
               }

               Code.sellerAB(var1, "chua co hang goi cc");
            }
         } else if (var2.equals("Hiện tại không online.") || var2.indexOf("em an com roi") != -1) {
            this.sellerBD = System.currentTimeMillis() - 55000L;
            return true;
         }

         return false;
      }
   }

   private static boolean sellerAA(String[] var0) {
      if (var0 != null && var0.length > 0) {
         for(int var1 = 0; var1 < var0.length; ++var1) {
            try {
               short var2 = Short.parseShort(var0[var1]);
               int var3 = 0;

               int var10000;
               while(true) {
                  if (var3 >= Char.getMyChar().arrItemBag.length) {
                     var10000 = -1;
                     break;
                  }

                  Item var4;
                  if ((var4 = Char.getMyChar().arrItemBag[var3]) != null && !var4.isLock && var4.template.id == var2) {
                     var10000 = var4.indexUI;
                     break;
                  }

                  ++var3;
               }

               if (var10000 != -1) {
                  return true;
               }
            } catch (NumberFormatException var5) {
            }
         }
      }

      return false;
   }

   private static boolean sellerAA(Item var0, String[] var1) {
      if (var1 != null && var1.length > 0 && var0 != null && !var0.isLock) {
         for(int var2 = 0; var2 < var1.length; ++var2) {
            try {
               if (Short.parseShort(var1[var2]) == var0.template.id) {
                  return true;
               }
            } catch (NumberFormatException var3) {
            }
         }
      }

      return false;
   }

   private static boolean sellerAC(String var0) {
      return !sellerBA.isEmpty() && sellerBA.contains(var0);
   }

   public static boolean sellerAA(String var0) {
      if (sellerAC(var0)) {
         sellerBA.removeElement(var0);
         return true;
      } else {
         return false;
      }
   }

   public static boolean sellerAB(String var0) {
      if (!sellerAC(var0)) {
         sellerBA.addElement(var0);
         return true;
      } else {
         return false;
      }
   }

   private static Char sellerAD(String var0) {
      if (var0 != null && var0.length() > 0) {
         for(int var1 = 0; var1 < GameScr.vCharInMap.size(); ++var1) {
            Char var2;
            if ((var2 = (Char)GameScr.vCharInMap.elementAt(var1)).cName.equals(var0)) {
               return var2;
            }
         }
      }

      return null;
   }

   private void sellerAR() {
      this.sellerBJ = null;
      this.sellerBK = null;
      if (super.advAM != null && !(super.advAM instanceof AutoGiaoDo)) {
         Code.advAC();
      } else {
         Code.endAuto();
      }
   }

   protected final void advAJ() {
      if (Auto.advAO()) {
         this.sellerAQ();
         Auto.advAA(true);
      } else if (super.mapID == TileMap.mapID && super.zoneID == TileMap.zoneID) {
         if (this.sellerBB == null) {
            if (GameScr.isPaintTrade) {
               GameScr.gI().resetButton();
               if (this.sellerAY != 0) {
                  this.sellerAQ();
               }
            }

            if ((this.sellerBB = sellerAD(this.sellerBK)) != null) {
               this.sellerBI = 0;
            } else {
               if (System.currentTimeMillis() - this.sellerBH > 6000L) {
                  if (this.sellerBI >= 10) {
                     this.sellerAQ();
                     this.sellerAR();
                     return;
                  }

                  ++this.sellerBI;
                  this.sellerBH = System.currentTimeMillis();
                  GameScr.paint("Không tìm thấy acc nhận đồ: " + this.sellerBK);
               }

            }
         } else {
            switch(this.sellerAY) {
            case -45:
               if (System.currentTimeMillis() - this.sellerAA > 35000L) {
                  GameCanvas.endDlg();
                  GameScr.gI().resetButton();
                  this.sellerAQ();
                  return;
               }
               break;
            case -37:
               if (System.currentTimeMillis() - this.sellerAA > 35000L) {
                  GameCanvas.endDlg();
                  GameScr.gI().resetButton();
                  this.sellerAQ();
                  return;
               }
               break;
            case 0:
               if (System.currentTimeMillis() - this.sellerAA > 35000L) {
                  this.sellerAA = System.currentTimeMillis();
                  this.sellerBB = sellerAD(this.sellerBK);
                  if (this.sellerBB != null) {
                     if (Math.abs(this.sellerBB.cx - Char.getMyChar().cx) > 60 || Math.abs(this.sellerBB.cy - Char.getMyChar().cy) > 40) {
                        Char.moveToChar(this.sellerBB.cx, this.sellerBB.cy);
                        Auto.sleep(2000L);
                     }

                     Service.gI().tradeInvite(this.sellerBB.charID);
                     return;
                  }
               }
               break;
            case 37:
               if (this.sellerAZ <= 0) {
                  this.sellerAQ();
                  this.sellerAR();
                  return;
               }

               if (GameScr.isPaintTrade && GameScr.arrItemTradeOrder != null) {
                  int var1 = 0;

                  for(int var2 = 0; var2 < Char.getMyChar().arrItemBag.length; ++var2) {
                     Item var3;
                     if (sellerAA(var3 = Char.getMyChar().arrItemBag[var2], this.sellerBJ)) {
                        GameScr.indexSelect = var3.indexUI;
                        GameScr.gI().actTradeSelectItem();
                        ++var1;
                        if (var1 >= this.sellerAZ || var1 >= 12) {
                           break;
                        }
                     }
                  }

                  this.sellerBL = var1;
                  Auto.sleep(1000L);
                  this.sellerAA = System.currentTimeMillis();
                  this.sellerAY = -37;
                  GameScr.gI().actTradeLock();
                  return;
               }

               if (System.currentTimeMillis() - this.sellerAA > 35000L) {
                  GameCanvas.endDlg();
                  GameScr.gI().resetButton();
                  this.sellerAQ();
                  return;
               }
               break;
            case 45:
               if (GameScr.gI().typeTradeOrder > 0 && System.currentTimeMillis() - this.sellerAA >= 6000L) {
                  this.sellerAA = System.currentTimeMillis();
                  this.sellerAY = -45;
                  GameScr.gI().actTradeAccept();
                  return;
               }

               if (System.currentTimeMillis() - this.sellerAA > 35000L) {
                  GameCanvas.endDlg();
                  GameScr.gI().resetButton();
                  this.sellerAQ();
                  return;
               }
               break;
            case 57:
               if (System.currentTimeMillis() - this.sellerAA > 2000L) {
                  this.sellerAQ();
                  return;
               }
               break;
            case 58:
               if (this.sellerAZ > this.sellerBL && sellerAA(this.sellerBJ)) {
                  this.sellerAQ();
                  this.sellerAZ -= this.sellerBL;
                  Auto.sleep(2000L);
                  return;
               }

               this.sellerAQ();
               this.sellerAR();
               return;
            }

         }
      } else {
         this.remap(super.mapID, super.zoneID, -1, -1);
      }
   }

   public final String toString() {
      return "Auto giao hàng";
   }

   static {
      String var0;
      if ((var0 = RMS.loadRMSString("chipSellerLists")) != null && var0.length() > 0) {
         String[] var2 = Code.advAC(var0, ";");

         for(int var1 = 0; var1 < var2.length; ++var1) {
            if (!sellerBA.contains(var2[var1])) {
               sellerBA.addElement(var2[var1]);
            }
         }
      }

   }
}
