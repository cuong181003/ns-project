public final class ScrollResult {
   public boolean isDowning;
   public int selected = -1;
   public boolean isFinish = false;
}
