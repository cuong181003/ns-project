public final class Lanterns {
   public int x;
   public int y;
   public int dy = 3;
   public int yStart;
   public boolean isEnd;

   public Lanterns(int var1, int var2) {
      this.x = var1;
      this.y = this.yStart = var2;
      this.isEnd = false;
   }
}
