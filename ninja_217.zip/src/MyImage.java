import javax.microedition.lcdui.Image;

public final class MyImage {
   public Image img = null;
   public long timerequest = 0L;
   public long timeUse = System.currentTimeMillis();
}
