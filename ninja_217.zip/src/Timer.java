public final class Timer {
   public static int idAction;
   public static long timeExecute;
   public static boolean isON;
}
