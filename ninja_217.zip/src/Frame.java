public final class Frame {
   public short[] dx;
   public short[] dy;
   public byte[] idImg;
   public byte[] flip;
   public byte[] onTop;
}
