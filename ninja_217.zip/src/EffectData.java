public final class EffectData {
   public byte[] data;

   public EffectData() {
      new MyVector();
      new MyVector();
   }
}
