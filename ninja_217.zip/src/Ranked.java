public final class Ranked {
   public int ranked;
   public String name;
   public String stt;
}
