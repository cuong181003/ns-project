public final class EffAtutoTemp {
   public ImageInfo[] imginfo;
   public Frame[] frameEffAuto;
   public short[] frameRunning;
   public long timerequest = 0L;
   public long timeUse = System.currentTimeMillis();
}
