public final class ItemOptionTemplate {
   public int id;
   public String name;
   public int type;
}
