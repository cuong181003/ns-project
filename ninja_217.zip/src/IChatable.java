
public interface IChatable {

    void onChatFromMe(String var1, String var2);

    void onCancelChat();
}
