public class BaseEPosition {
}
