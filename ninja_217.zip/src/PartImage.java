public final class PartImage {
   public short id;
   public byte dx;
   public byte dy;
}
