public final class ItemStands {
   public Item item;
   public int price;
   public int timeEnd;
   public int timeStart;
   public String seller = "";
}
