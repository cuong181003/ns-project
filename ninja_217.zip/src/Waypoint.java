public final class Waypoint {
   public short minX;
   public short minY;
   public short maxX;
   public short maxY;

   public Waypoint(short var1, short var2, short var3, short var4) {
      this.minX = var1;
      this.minY = var2;
      this.maxX = var3;
      this.maxY = var4;
   }
}
